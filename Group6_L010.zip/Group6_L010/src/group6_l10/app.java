package group6_l10;

public class app
{

    public static void main(String args[])
    {
        MainFrame mjf = new MainFrame();
    }
}