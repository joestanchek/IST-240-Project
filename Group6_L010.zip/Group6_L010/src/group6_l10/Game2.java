package group6_l10;

import javax.swing.*;
import java.awt.event.*;

public class Game2 extends JPanel {

    JFrame mainFrame;
    JFrame frame;

    public Game2(JFrame mainFrame) {
        this.mainFrame = mainFrame;
        frame = new JFrame();
        frame.setContentPane(this);
        frame.setSize(300, 200);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setTitle("Game 2");
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
    }

    @SuppressWarnings("unchecked")

    private void initComponents() {

        jButton1 = new JButton();
        jLabel1 = new JLabel();
        jButton1.setText("Main Map");
        jButton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setText("Game 2 will be here");

        GroupLayout layout = new GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup().addGap(58, 58, 58)
                                                .addComponent(jButton1))
                                        .addGroup(layout.createSequentialGroup().addGap(47, 47, 47).addComponent(jLabel1)))
                                .addContainerGap(260, Short.MAX_VALUE)));
        layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup().addGap(44, 44, 44).addComponent(jLabel1).addGap(33, 33, 33)
                        .addComponent(jButton1).addContainerGap(186, Short.MAX_VALUE)));
    }

    private void jButton1ActionPerformed(ActionEvent evt) {

        frame.dispose();
        mainFrame.setVisible(true);
    }
    private JButton jButton1;
    private JLabel jLabel1;

}
