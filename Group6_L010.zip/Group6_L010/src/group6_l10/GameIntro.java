package group6_l10;

import javax.swing.*;
import java.awt.event.*;

public class GameIntro extends JPanel 
{

    static JFrame frame;
    JButton about;
    JButton instructions;
    JLabel jLabel1;
    JButton mainMap;
    JButton options;

   
    public GameIntro() 
    {

   jLabel1 = new JLabel("Welcome to the Game");
        mainMap = new JButton("Main Map");
        options = new JButton("Options");
        instructions = new JButton("Instructions");
        about = new JButton("About");
        mainMap.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent evt) 
            {
                
                new MainMap(MainFrame.frame);
            }
        });
        options.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent evt) 
            {
                new Options(MainFrame.frame);

            }
        });

        instructions.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent evt) 
            {
                new Instructions(MainFrame.frame);

            }
        });

     
        about.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent evt) 
            {
               
                new About(MainFrame.frame);
            }
        });

  
        GroupLayout layout = new GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup().addGap(157, 157, 157).addComponent(jLabel1))
        .addGroup(layout.createSequentialGroup().addContainerGap().addComponent(mainMap)
        .addGap(37, 37, 37).addComponent(options).addGap(35, 35, 35)
        .addComponent(instructions).addGap(40, 40, 40).addComponent(about)))
        .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
        
        layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup().addGap(45, 45, 45).addComponent(jLabel1).addGap(50, 50, 50)
        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(mainMap)
        .addComponent(options).addComponent(instructions).addComponent(about))
        .addContainerGap(36, Short.MAX_VALUE)));
        
    }
}
    


