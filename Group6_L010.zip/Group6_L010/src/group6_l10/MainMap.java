package group6_l10;


import javax.swing.*;
import java.awt.event.*;


public class MainMap extends JPanel {

    JFrame introScreen;
    JFrame frame;
    private JButton jButton1;
    private JButton jButton2;
    private JButton jButton3;
    private JButton jButton5;
    
   

    public MainMap(JFrame introScreen) {
        this.introScreen = introScreen;
        frame = new JFrame();
        frame.setContentPane(this);
        frame.setSize(500, 200);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setTitle("Main Game");
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
         jButton1 = new JButton();
        jButton2 = new JButton();
        jButton3 = new JButton();
        jButton5 = new JButton();
       

       
        jButton1.setText("Game 1");
        jButton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                new Game1(frame);
            }
        });

        
        jButton2.setText("Game 2");
        jButton2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                new Game2(frame);
            }
        });

       
        jButton3.setText("Game 3");
        jButton3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                new Game3(frame);
            }
        });

        
        jButton5.setText("Go Home");
        jButton5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                introScreen.setVisible(true);
            }
        });

        
       

        
        GroupLayout layout = new GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup()
                .addContainerGap().addComponent(jButton1)
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup().addComponent(jButton5).addGap(35, 35, 35)
                .addGap(0, 0, Short.MAX_VALUE))
                .addGroup(layout.createSequentialGroup().addComponent(jButton2).addGap(20, 20, 20)
                .addComponent(jButton3).addGap(20, 20, 20)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED,
                GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))).addContainerGap()));
        
        layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup().addGap(80, 80, 80)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(jButton1).addComponent(jButton2).addComponent(jButton3))
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(jButton5)
)));
    }

    
   

  

   
}
