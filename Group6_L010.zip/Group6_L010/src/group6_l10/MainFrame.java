package group6_l10;

import java.awt.*;
import javax.swing.*;

public class MainFrame extends JFrame {

    GameIntro game;
    static JFrame frame;

    public MainFrame() {
        super("Group6_L10");
        game = new GameIntro();
        //frame = new JFrame();
        getContentPane().add(game, "Center");
        setSize(500, 200);
        setLocationRelativeTo(null);
        setVisible(true);
        setTitle("Game Introduction");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    public void MacLayoutSetup() {
        // On some MACs it might be necessary to have the statement below 
        //for the background color of the button to appear 
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
