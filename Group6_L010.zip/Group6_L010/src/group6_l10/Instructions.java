package group6_l10;

import javax.swing.*;
import java.awt.event.*;

public class Instructions extends JPanel 
{

    JFrame introScreen;
    JFrame frame;
    JButton jButton1;
    JLabel jLabel1;

    public Instructions(JFrame introScreen) 
    {
        this.introScreen = introScreen;
        frame = new JFrame();
        frame.setContentPane(this);
        frame.setSize(300, 200);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setTitle("Game Instructions");
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jButton1 = new JButton();
        jLabel1 = new JLabel();
        jButton1.setText("Go Home");
        jButton1.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent evt) 
            {
                introScreen.setVisible(true);
            }
        });

        jLabel1.setText("Instructions");

        GroupLayout layout = new GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
        layout.createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup().addGap(90, 90, 90)
        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
        .addComponent(jButton1).addGroup(layout.createSequentialGroup()
        .addGap(20, 20, 20).addComponent(jLabel1)))
        .addContainerGap(100, Short.MAX_VALUE)));
        
        layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup().addGap(50, 50, 50).addComponent(jLabel1).addGap(40, 40, 40)
        .addComponent(jButton1).addContainerGap(70, Short.MAX_VALUE)));
    
    }
}

        
    

    


