package group6_l10;

import javax.swing.*;
import java.awt.event.*;

public class About extends JPanel {

    JFrame introScreen;
    JFrame frame;

    
    public About(JFrame introScreen) {
        this.introScreen = introScreen;
        frame = new JFrame();
        frame.setContentPane(this);
        frame.setSize(300, 200);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setTitle("Game Credits");
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jLabel1 = new JLabel();
        jButton1 = new JButton();

        jLabel1.setText(" Game Credits");
        
        jButton1.setText("Go Home");
        jButton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

      
        GroupLayout layout = new GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup().addGap(109, 109, 109)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 82,
                                        GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton1))
                        .addContainerGap(91, Short.MAX_VALUE)));
        layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup().addGap(37, 37, 37)
                        .addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 44,
                                GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18).addComponent(jButton1).addContainerGap(44, Short.MAX_VALUE)));
    }

    
    private void jButton1ActionPerformed(ActionEvent evt) {
        frame.dispose();
        introScreen.setVisible(true);
    }

    
    private JButton jButton1;
    private JLabel jLabel1;
}
